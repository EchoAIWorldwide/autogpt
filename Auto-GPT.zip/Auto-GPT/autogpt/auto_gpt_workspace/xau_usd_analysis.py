import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load data
xau_usd = pd.read_csv('xau_usd.csv')

# Plot closing prices
plt.plot(xau_usd['Close'])
plt.title('XAU/USD Closing Prices')
plt.xlabel('Time')
plt.ylabel('Price')
plt.show()