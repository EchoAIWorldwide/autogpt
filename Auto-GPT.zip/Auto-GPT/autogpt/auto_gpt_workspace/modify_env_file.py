# Import the os module
import os

# Open the .env file for reading
with open('.env', 'r') as f:
    # Read the contents of the file
    contents = f.read()

# Modify the contents of the file
contents = contents.replace('ELEVENLABS_TTS_API_KEY', '')
contents = contents.replace('ELEVENLABS_TTS_API_SECRET', '')
contents = contents.replace('ELEVENLABS_TTS_VOICE', '')

# Open a new .env file for writing
with open('.env.new', 'w') as f:
    # Write the modified contents to the new file
    f.write(contents)

# Delete the old .env file
os.remove('.env')

# Rename the new .env file to '.env'
os.rename('.env.new', '.env')

# Print a message to confirm that the modifications have been made
print('ElevenLabs TTS has been disabled.')