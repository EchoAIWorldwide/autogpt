import subprocess

subprocess.call(['pip', 'install', 'google-cloud-texttospeech'])
