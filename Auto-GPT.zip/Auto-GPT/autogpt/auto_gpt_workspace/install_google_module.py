import os

os.system('pip install google-cloud-texttospeech')