# Import libraries
import requests
from bs4 import BeautifulSoup
import csv

# Define URL and headers
url = 'https://www.investing.com/commodities/gold-historical-data'
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'}

# Send GET request
response = requests.get(url, headers=headers)

# Parse HTML content
soup = BeautifulSoup(response.content, 'html.parser')

# Find table
table = soup.find('table', {'id': 'curr_table'})

# Find table rows
rows = table.find_all('tr')

# Open CSV file
with open('gold_data.csv', 'w', newline='') as file:
    writer = csv.writer(file)

    # Write header row
    header = [th.text for th in rows[0].find_all('th')]
    writer.writerow(header)

    # Write data rows
    for row in rows[1:]:
        data = [td.text for td in row.find_all('td')]
        writer.writerow(data)
