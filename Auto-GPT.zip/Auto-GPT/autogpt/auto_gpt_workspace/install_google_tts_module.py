# Install the Google Cloud Text-to-Speech API module using pip
!pip install --upgrade google-cloud-texttospeech