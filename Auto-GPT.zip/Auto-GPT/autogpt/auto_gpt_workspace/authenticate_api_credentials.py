"""Authenticate the Google Cloud Text-to-Speech API credentials using the google-auth library."""

# Import libraries
import google.auth
from google.oauth2.service_account import Credentials

# Authenticate the Google Cloud Text-to-Speech API credentials
credentials, project_id = google.auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'])
