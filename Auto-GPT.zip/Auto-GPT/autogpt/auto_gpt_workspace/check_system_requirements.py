# Python script to check system requirements for Google Cloud Text-to-Speech installation
import platform
import sys

# Check Python version
if sys.version_info < (3, 6):
    print('Error: Python version 3.6 or higher is required.')
    sys.exit(1)

# Check operating system
if platform.system() != 'Windows':
    print('Error: Windows operating system is required.')
    sys.exit(1)

# Check architecture
if platform.machine() != 'AMD64':
    print('Error: 64-bit architecture is required.')
    sys.exit(1)

print('System requirements met.')