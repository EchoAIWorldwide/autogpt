# Import the os module
import os

# Open the .env file for writing
with open('.env', 'a') as f:
    # Write the DISABLE_ELEVENLABS_TTS variable to the file
    f.write('DISABLE_ELEVENLABS_TTS=True\n')

# Print a message to confirm that the variable has been added
print('ElevenLabs TTS has been disabled.')