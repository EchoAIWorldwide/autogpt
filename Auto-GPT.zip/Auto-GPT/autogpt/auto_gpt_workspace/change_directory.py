# Python script to change working directory to directory where script is located
import os

# Change working directory to directory where script is located
os.chdir(os.path.dirname(os.path.abspath(__file__)))

print('Working directory changed to:', os.getcwd())